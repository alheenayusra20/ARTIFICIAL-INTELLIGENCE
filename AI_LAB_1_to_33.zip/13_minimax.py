# Minimax
print('Minimax')