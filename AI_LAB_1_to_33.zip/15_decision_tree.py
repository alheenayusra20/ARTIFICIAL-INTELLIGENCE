# Decision tree
print('Decision tree')