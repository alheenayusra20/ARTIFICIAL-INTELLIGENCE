# A*
print('A*')