# Vacuum cleaner
print('Vacuum')