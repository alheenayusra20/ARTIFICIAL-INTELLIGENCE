# Crypt arithmetic
print('Cryptarithm')