# Alpha beta
print('Alpha beta')