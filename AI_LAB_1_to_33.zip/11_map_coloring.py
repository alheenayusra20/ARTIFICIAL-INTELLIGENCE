# CSP map coloring
print('Map coloring')