# Python 8-puzzle placeholder
print('8 Puzzle solution')