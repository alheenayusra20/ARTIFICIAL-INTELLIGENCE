# DFS
print('DFS')