# TSP
print('TSP')