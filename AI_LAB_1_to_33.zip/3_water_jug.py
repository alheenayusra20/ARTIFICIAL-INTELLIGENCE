# Water jug
print('Water Jug')