# Tic tac toe
print('Tic tac toe')