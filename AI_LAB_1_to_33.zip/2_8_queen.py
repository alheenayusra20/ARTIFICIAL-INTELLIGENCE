# Python 8-Queen
print('8 Queen solution')