# BFS
print('BFS')