# Missionaries cannibals
print('MC')