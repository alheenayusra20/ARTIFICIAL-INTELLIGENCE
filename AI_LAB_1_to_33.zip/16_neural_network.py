# Neural network
print('NN')